<?php
/**
 * This file will include all available function files.
 * 
 * @package bootstrap-basic4
 */


