<?php
/**
 * Widget template for display search form in search widget.
 * 
 * @package bootstrap-basic4
 */


get_template_part('template-parts/partial', 'search-form');
?>